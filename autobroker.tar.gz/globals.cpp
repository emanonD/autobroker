#include "globals.h"

namespace
{
		dbase db;
}