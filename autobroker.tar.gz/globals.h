#include "dbase/dbase.h"

extern dbase db;